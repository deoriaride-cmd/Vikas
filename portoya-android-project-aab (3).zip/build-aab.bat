@echo off
echo ========================================================
echo  Building Portoya (.aab) Android App Bundle
echo  Package: com.portoya.app
echo  Version: 1.0.0 (1)
echo ========================================================

call gradlew.bat clean
call gradlew.bat bundleRelease

echo ========================================================
echo  BUILD SUCCESSFUL!
echo  Your AAB file is generated at:
echo  app\build\outputs\bundle\release\app-release.aab
echo  Ready to upload to Google Play Console!
echo ========================================================
pause
