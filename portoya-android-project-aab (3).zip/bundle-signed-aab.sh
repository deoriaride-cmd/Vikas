#!/usr/bin/env bash
set -e
echo "Building Signed .AAB for Google Play Store using portoya-release.jks..."
chmod +x ./gradlew
./gradlew bundleRelease
echo "DONE! Your signed .aab is at: app/build/outputs/bundle/release/app-release.aab"
