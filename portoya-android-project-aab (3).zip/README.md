# Portoya - Android App Bundle (.aab) Project

This is the production-ready Android Studio WebView project for **Portoya** (https://portoya.com).
It is configured to build the **Google Play Store Android App Bundle (.aab)** file.

---

## 🚀 How to Build the .AAB File

### Method 1: Using Android Studio (Recommended & Easiest)
1. Download and extract this project zip file.
2. Open **Android Studio** (Hedgehog, Iguana, Jellyfish, or newer).
3. Click **File > Open...** and select this extracted folder.
4. Let Gradle sync and download required libraries (1-2 minutes).
5. In the top menu, click **Build > Generate Signed Bundle / APK...**
6. Select **Android App Bundle (.aab)** and click **Next**.
7. Select or create your Keystore file (.jks), enter password and key alias.
8. Select build variant **release** and click **Create**.
9. Your signed `.aab` will be output to `app/release/app-release.aab`.
10. Upload `app-release.aab` directly to Google Play Console!

---

### Method 2: Command Line (Fastest)

**On Mac / Linux:**
```bash
chmod +x ./gradlew
./gradlew bundleRelease
```

**On Windows:**
```cmd
gradlew.bat bundleRelease
```

Your generated `.aab` bundle will be located at:
```
app/build/outputs/bundle/release/app-release.aab
```

---

## 🔑 Generating a Keystore for Google Play
Run this command in terminal to create your signing keystore:
```bash
keytool -genkey -v -keystore portoya-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias portoya
```

---

## 📱 Features Included
- **Target SDK 34** (Full Google Play Store 2024-2026 compliance)
- **High Performance WebView** with hardware acceleration
- **Swipe-to-Refresh** gesture support
- **Progress Bar** for page loading feedback
- **Deep Linking** for https://portoya.com
- **Offline Fallback Page** when device loses connection
- **Back Navigation Handling** to prevent accidental app exit
- **External App Scheme Handling** (WhatsApp, Tel, Email, SMS)
- **File Upload & Camera Picker** integration
