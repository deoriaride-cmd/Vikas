@echo off
echo Building Signed .AAB for Google Play Store using portoya-release.jks...
call gradlew.bat bundleRelease
echo DONE! Your signed .aab is at: app\build\outputs\bundle\release\app-release.aab
pause
