#!/usr/bin/env bash
# Script to build Release Android App Bundle (.aab) for Google Play Store
set -e

echo "========================================================"
echo " Building Portoya (.aab) Android App Bundle"
echo " Package: com.portoya.app"
echo " Version: 1.0.0 (1)"
echo " Target:  https://portoya.com"
echo "========================================================"

# Make gradlew executable
chmod +x ./gradlew

# Clean build
./gradlew clean

# Build Android App Bundle (.aab)
./gradlew bundleRelease

echo "========================================================"
echo " BUILD SUCCESSFUL!"
echo " Your AAB file is generated at:"
echo " app/build/outputs/bundle/release/app-release.aab"
echo " Ready to upload to Google Play Console!"
echo "========================================================"
