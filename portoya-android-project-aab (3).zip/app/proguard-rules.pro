# Proguard rules for Portoya WebView App
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-dontwarn androidx.webkit.**
-keep class androidx.webkit.** { *; }
